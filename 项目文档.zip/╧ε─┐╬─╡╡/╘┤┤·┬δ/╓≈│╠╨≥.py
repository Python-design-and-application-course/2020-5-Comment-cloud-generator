import 图书
import 音乐
import 影视
import easygui as g

def main():
    while 1:
        #g.buttonbox(msg='', image='选择.png',title='评论词云生成器', choices=('图书', ' 音乐 ', ' 影视'))
        choice = g.buttonbox(title='评论词云生成器',choices = ('图书', '音乐', '影视'),image = '选择.png')

        if choice == '图书':
            ok = 图书.main()
            ok
            if ok == 0:
                g.buttonbox(msg='', image='错误.png',title='评论词云生成器', choices=(''))
        elif choice == '音乐':
            ok = 音乐.main()
            ok
            if ok == 0:
                g.buttonbox(msg='', image='错误.png',title='评论词云生成器', choices=(''))
        elif choice == '影视':
            ok = 影视.main()
            ok
            if ok == 0:
                g.buttonbox(msg='', image='错误.png',title='评论词云生成器', choices=(''))
        choice = g.buttonbox(msg='', image='继续.png', title='评论词云生成器', choices=('继续', '退出'))
        if choice == '退出':
            break
    g.buttonbox(msg='',image='再次使用.png' ,title='评论词云生成器', choices=(''))


if __name__=="__main__":
    main()

